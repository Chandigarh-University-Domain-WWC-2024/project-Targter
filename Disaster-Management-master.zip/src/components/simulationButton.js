import React from 'react'

const SimulationButton = () => {
  return (
    <div className="simulationButton">
      Run Test
    </div>
  )
}

export default SimulationButton
