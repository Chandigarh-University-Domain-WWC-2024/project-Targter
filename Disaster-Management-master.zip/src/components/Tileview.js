import React from 'react'

const Tileview = () => {
  return (
    <div>
      tileview
    </div>
  );
}

export default Tileview
